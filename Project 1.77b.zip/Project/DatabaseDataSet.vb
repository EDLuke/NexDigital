﻿Partial Class DatabaseDataSet
    Partial Class CategoryDataTable

    End Class

End Class
