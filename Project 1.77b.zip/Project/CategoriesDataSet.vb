﻿Partial Class CategoriesDataSet
    Partial Class CategoryDataTable

    End Class

End Class
