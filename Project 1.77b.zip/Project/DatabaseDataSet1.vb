﻿Partial Class DatabaseDataSet1
End Class

Namespace DatabaseDataSet1TableAdapters

    Partial Public Class ItemsTableAdapter
    End Class
End Namespace
