﻿Public Class frmClock

End Class